/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Calculator, 
  Languages, 
  TrendingUp, 
  Plus, 
  Trash2, 
  Search, 
  FileText, 
  Globe, 
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ArrowRightLeft,
  DollarSign,
  ShieldCheck,
  Truck,
  ShoppingCart,
  Wallet,
  Receipt,
  Calendar,
  ArrowUpCircle,
  ArrowDownCircle,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";

// --- Types ---
interface ComponentItem {
  id: string;
  brand: string;
  productLine: string;
  capacity: string;
  sn: string;
  quantity: number;
  status: 'Chưa kiểm định' | 'Đang kiểm định' | 'Đạt' | 'Lỗi';
  importPriceTWD: number;
  importDate: string;
}

interface SaleItem {
  id: string;
  itemId: string; // Reference to inventory item
  customerName: string;
  quantity: number;
  salePriceVND: number;
  saleDate: string;
  paymentStatus: 'Đã thanh toán' | 'Chưa thanh toán' | 'Cọc';
}

interface FinanceItem {
  id: string;
  type: 'Thu' | 'Chi';
  category: string;
  amount: number;
  date: string;
  note: string;
}

interface FinancialParams {
  exchangeRate: number;
  shippingFee: number;
  importTax: number;
  testingFee: number;
  warrantyFee: number;
  targetProfit: number;
}

// --- Constants ---
const DEFAULT_EXCHANGE_RATE = 815; // TWD/VND (Example)

// --- Helper Functions ---
const cleanBrand = (brand: string) => {
  let cleaned = brand.trim();
  if (cleaned.toLowerCase() === 'western digital') return 'WD';
  return cleaned;
};

const cleanProductLine = (line: string) => {
  // Remove content in parentheses like (Re/RE4/Enterprise)
  return line.replace(/\s*\(.*?\)\s*/g, '').trim();
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'stock' | 'calculator' | 'trade' | 'sales' | 'finance'>('dashboard');
  const [inventory, setInventory] = useState<ComponentItem[]>([]);
  const [sales, setSales] = useState<SaleItem[]>([]);
  const [finance, setFinance] = useState<FinanceItem[]>([]);
  const [isFetchingRate, setIsFetchingRate] = useState(false);
  const [tradeLang, setTradeLang] = useState<'zh' | 'en' | 'vi'>('zh');
  const [tradeText, setTradeText] = useState('');
  const [translations, setTranslations] = useState<{ zh?: string; en?: string; vi?: string; pinyin?: string }>({});
  const [isTranslating, setIsTranslating] = useState(false);
  
  const [financialParams, setFinancialParams] = useState<FinancialParams>({
    exchangeRate: DEFAULT_EXCHANGE_RATE,
    shippingFee: 25000,
    importTax: 0,
    testingFee: 10000,
    warrantyFee: 30000,
    targetProfit: 25,
  });

  // --- Gemini AI Setup ---
  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' }), []);

  const fetchLatestRate = async () => {
    if (isFetchingRate) return;
    setIsFetchingRate(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "What is the current TWD to VND exchange rate? Return only the numerical value as a JSON object with a 'rate' property.",
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              rate: { type: Type.NUMBER }
            },
            required: ["rate"]
          }
        }
      });
      
      const data = JSON.parse(response.text || '{}');
      if (data.rate) {
        setFinancialParams(prev => ({ ...prev, exchangeRate: data.rate }));
      }
    } catch (error) {
      console.error("Error fetching rate:", error);
    } finally {
      setIsFetchingRate(false);
    }
  };

  // --- State for Forms ---
  const [newItem, setNewItem] = useState<Omit<ComponentItem, 'id'>>({
    brand: '',
    productLine: '',
    capacity: '',
    sn: '',
    quantity: 1,
    status: 'Chưa kiểm định',
    importPriceTWD: 0,
    importDate: new Date().toISOString().split('T')[0],
  });

  const [newSale, setNewSale] = useState<Omit<SaleItem, 'id'>>({
    itemId: '',
    customerName: '',
    quantity: 1,
    salePriceVND: 0,
    saleDate: new Date().toISOString().split('T')[0],
    paymentStatus: 'Chưa thanh toán',
  });

  const [newFinance, setNewFinance] = useState<Omit<FinanceItem, 'id'>>({
    type: 'Chi',
    category: '',
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    note: '',
  });

  // --- Calculations ---
  const stats = useMemo(() => {
    const totalImportItems = inventory.reduce((sum, item) => sum + item.quantity, 0);
    const totalStockItems = inventory.reduce((sum, item) => {
      const soldQty = sales.filter(s => s.itemId === item.id).reduce((sSum, s) => sSum + s.quantity, 0);
      return sum + (item.quantity - soldQty);
    }, 0);
    
    const testedItems = inventory.filter(i => i.status === 'Đạt').reduce((sum, item) => sum + item.quantity, 0);
    const errorItems = inventory.filter(i => i.status === 'Lỗi').reduce((sum, item) => sum + item.quantity, 0);
    
    const totalImportCostVND = inventory.reduce((sum, item) => {
      const itemCost = (item.importPriceTWD * financialParams.exchangeRate) + 
                       (financialParams.shippingFee + financialParams.testingFee + financialParams.warrantyFee);
      return sum + (itemCost * item.quantity);
    }, 0);

    const totalSalesVND = sales.reduce((sum, sale) => sum + (sale.salePriceVND * sale.quantity), 0);
    
    const totalIncome = finance.filter(f => f.type === 'Thu').reduce((sum, f) => sum + f.amount, 0);
    const totalExpense = finance.filter(f => f.type === 'Chi').reduce((sum, f) => sum + f.amount, 0);

    return { totalImportItems, totalStockItems, testedItems, errorItems, totalImportCostVND, totalSalesVND, totalIncome, totalExpense };
  }, [inventory, financialParams, sales, finance]);

  const calculateFinalPrice = (twdPrice: number) => {
    const baseCostVND = twdPrice * financialParams.exchangeRate;
    const taxVND = (financialParams.importTax / 100) * baseCostVND;
    const totalExpenses = financialParams.shippingFee + taxVND + financialParams.testingFee + financialParams.warrantyFee;
    const totalCost = baseCostVND + totalExpenses;
    const finalPrice = totalCost * (1 + financialParams.targetProfit / 100);
    
    return {
      baseCostVND,
      totalExpenses,
      totalCost,
      finalPrice
    };
  };

  // --- Handlers ---
  const handleAddItem = () => {
    if (!newItem.brand) return;
    
    const item: ComponentItem = {
      ...newItem,
      id: Math.random().toString(36).substr(2, 9),
      brand: cleanBrand(newItem.brand),
      productLine: cleanProductLine(newItem.productLine),
    };
    
    setInventory([...inventory, item]);
    setNewItem({
      brand: '',
      productLine: '',
      capacity: '',
      sn: '',
      quantity: 1,
      status: 'Chưa kiểm định',
      importPriceTWD: 0,
      importDate: new Date().toISOString().split('T')[0],
    });
  };

  const handleAddSale = () => {
    if (!newSale.itemId || !newSale.customerName) return;
    const sale: SaleItem = {
      ...newSale,
      id: Math.random().toString(36).substr(2, 9),
    };
    setSales([...sales, sale]);
    setNewSale({
      itemId: '',
      customerName: '',
      quantity: 1,
      salePriceVND: 0,
      saleDate: new Date().toISOString().split('T')[0],
      paymentStatus: 'Chưa thanh toán',
    });
  };

  const handleAddFinance = () => {
    if (!newFinance.category || !newFinance.amount) return;
    const item: FinanceItem = {
      ...newFinance,
      id: Math.random().toString(36).substr(2, 9),
    };
    setFinance([...finance, item]);
    setNewFinance({
      type: 'Chi',
      category: '',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      note: '',
    });
  };

  const deleteItem = (id: string) => {
    setInventory(inventory.filter(i => i.id !== id));
  };

  const deleteSale = (id: string) => {
    setSales(sales.filter(s => s.id !== id));
  };

  const deleteFinance = (id: string) => {
    setFinance(finance.filter(f => f.id !== id));
  };

  const handleTranslate = async () => {
    if (!tradeText.trim() || isTranslating) return;
    setIsTranslating(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Translate the following business inquiry text into Traditional Chinese, English, and Vietnamese. 
        Also provide the Pinyin for the Traditional Chinese translation.
        Text: "${tradeText}"
        Return as a JSON object with keys: 'zh', 'en', 'vi', 'pinyin'.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              zh: { type: Type.STRING },
              en: { type: Type.STRING },
              vi: { type: Type.STRING },
              pinyin: { type: Type.STRING }
            },
            required: ["zh", "en", "vi", "pinyin"]
          }
        }
      });

      const data = JSON.parse(response.text || '{}');
      setTranslations(data);
    } catch (error) {
      console.error("Translation error:", error);
    } finally {
      setIsTranslating(false);
    }
  };

  // --- Render Sections ---
  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Tổng tồn kho', value: stats.totalStockItems, icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Doanh số (VND)', value: stats.totalSalesVND.toLocaleString(), icon: ShoppingCart, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Tổng Thu (VND)', value: stats.totalIncome.toLocaleString(), icon: ArrowUpCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Tổng Chi (VND)', value: stats.totalExpense.toLocaleString(), icon: ArrowDownCircle, color: 'text-rose-600', bg: 'bg-rose-50' },
        ].map((stat, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`${stat.bg} p-6 rounded-2xl border border-white/50 shadow-sm flex items-center gap-4`}
          >
            <div className={`p-3 rounded-xl bg-white shadow-sm ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <TrendingUp size={20} className="text-blue-600" />
            Phân tích Lợi nhuận Dự kiến
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Lợi nhuận mục tiêu:</span>
              <span className="font-bold text-blue-600">{financialParams.targetProfit}%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Tỷ giá TWD/VND:</span>
              <span className="font-bold text-gray-800">{financialParams.exchangeRate}</span>
            </div>
            <div className="pt-4 border-t border-dashed border-gray-200">
              <p className="text-sm text-gray-500 italic">
                * Dữ liệu được tính toán dựa trên cấu hình tài chính hiện tại.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <ArrowRightLeft size={20} className="text-orange-600" />
            Tỷ giá & Thanh toán
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-orange-50 rounded-xl border border-orange-100">
              <p className="text-sm text-orange-800 font-medium mb-1">Lời khuyên thanh toán:</p>
              <p className="text-sm text-orange-700">
                Theo dõi biểu đồ XAUUSD. Nếu vàng giảm mạnh, USD thường tăng, có thể ảnh hưởng đến TWD. 
                Nên chốt tỷ giá khi TWD/VND dưới 810.
              </p>
            </div>
            <button 
              onClick={() => setActiveTab('trade')}
              className="w-full py-2 bg-white border border-orange-200 text-orange-600 rounded-lg font-medium hover:bg-orange-50 transition-colors"
            >
              Xem chi tiết Giao thương
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderInventory = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Plus size={20} className="text-blue-600" />
          Nhập kho Linh kiện Mới
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-4">
          <input 
            placeholder="Thương hiệu" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.brand}
            onChange={e => setNewItem({...newItem, brand: e.target.value})}
          />
          <input 
            placeholder="Dòng sản phẩm - Không bắt buộc" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.productLine}
            onChange={e => setNewItem({...newItem, productLine: e.target.value})}
          />
          <input 
            placeholder="Dung lượng" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.capacity}
            onChange={e => setNewItem({...newItem, capacity: e.target.value})}
          />
          <input 
            placeholder="Serial Number (SN) - Không bắt buộc" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.sn}
            onChange={e => setNewItem({...newItem, sn: e.target.value})}
          />
          <input 
            type="number"
            placeholder="Số lượng" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.quantity || ''}
            onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})}
          />
          <input 
            type="number"
            placeholder="Giá nhập (TWD)" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            value={newItem.importPriceTWD || ''}
            onChange={e => setNewItem({...newItem, importPriceTWD: Number(e.target.value)})}
          />
          <button 
            onClick={handleAddItem}
            className="bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <Plus size={18} /> Nhập kho
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <h3 className="font-bold text-gray-800">Danh sách Nhập kho</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              placeholder="Tìm kiếm SN..." 
              className="pl-10 pr-4 py-1.5 border border-gray-200 rounded-full text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 text-gray-500 uppercase text-xs font-bold">
              <tr>
                <th className="px-6 py-4">Thương hiệu</th>
                <th className="px-6 py-4">Dòng SP</th>
                <th className="px-6 py-4">Dung lượng</th>
                <th className="px-6 py-4">Serial Number</th>
                <th className="px-6 py-4 text-center">Số lượng</th>
                <th className="px-6 py-4">Giá nhập (TWD)</th>
                <th className="px-6 py-4">Giá trị (TWD)</th>
                <th className="px-6 py-4">Giá trị (VND)</th>
                <th className="px-6 py-4">Trạng thái</th>
                <th className="px-6 py-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <AnimatePresence>
                {inventory.map((item) => (
                  <motion.tr 
                    key={item.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="hover:bg-blue-50/30 transition-colors"
                  >
                    <td className="px-6 py-4 font-medium text-gray-900">{item.brand}</td>
                    <td className="px-6 py-4 text-gray-600">{item.productLine || 'N/A'}</td>
                    <td className="px-6 py-4 text-gray-600">{item.capacity}</td>
                    <td className="px-6 py-4 font-mono text-xs text-blue-600">{item.sn || 'N/A'}</td>
                    <td className="px-6 py-4 text-center">
                      <input 
                        type="number"
                        className="w-16 p-1 border border-gray-200 rounded text-center"
                        value={item.quantity}
                        onChange={(e) => {
                          const newQty = Number(e.target.value);
                          setInventory(inventory.map(i => i.id === item.id ? {...i, quantity: newQty} : i));
                        }}
                      />
                    </td>
                    <td className="px-6 py-4 text-gray-900 font-bold">{item.importPriceTWD.toLocaleString()}</td>
                    <td className="px-6 py-4 text-blue-600 font-bold">{(item.importPriceTWD * item.quantity).toLocaleString()}</td>
                    <td className="px-6 py-4 text-emerald-600 font-bold">{(item.importPriceTWD * item.quantity * financialParams.exchangeRate).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <select 
                        value={item.status}
                        onChange={(e) => {
                          const newStatus = e.target.value as ComponentItem['status'];
                          setInventory(inventory.map(i => i.id === item.id ? {...i, status: newStatus} : i));
                        }}
                        className={`px-2 py-1 rounded-full text-xs font-bold border-none outline-none cursor-pointer ${
                          item.status === 'Đạt' ? 'bg-green-100 text-green-700' :
                          item.status === 'Lỗi' ? 'bg-red-100 text-red-700' :
                          item.status === 'Đang kiểm định' ? 'bg-orange-100 text-orange-700' :
                          'bg-gray-100 text-gray-700'
                        }`}
                      >
                        <option>Chưa kiểm định</option>
                        <option>Đang kiểm định</option>
                        <option>Đạt</option>
                        <option>Lỗi</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => deleteItem(item.id)}
                        className="text-red-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
              {inventory.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-6 py-12 text-center text-gray-400 italic">
                    Chưa có linh kiện nào được nhập kho.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderStock = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <h3 className="font-bold text-gray-800">Bảng Thống kê Tồn kho</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              placeholder="Tìm kiếm linh kiện..." 
              className="pl-10 pr-4 py-1.5 border border-gray-200 rounded-full text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 text-gray-500 uppercase text-xs font-bold">
              <tr>
                <th className="px-6 py-4">Thương hiệu</th>
                <th className="px-6 py-4">Dòng SP</th>
                <th className="px-6 py-4">Dung lượng</th>
                <th className="px-6 py-4">Serial Number</th>
                <th className="px-6 py-4 text-center">Số lượng tồn</th>
                <th className="px-6 py-4">Giá nhập (TWD)</th>
                <th className="px-6 py-4">Giá trị tồn (TWD)</th>
                <th className="px-6 py-4">Giá trị tồn (VND)</th>
                <th className="px-6 py-4">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {inventory.map((item) => {
                const soldQty = sales.filter(s => s.itemId === item.id).reduce((sum, s) => sum + s.quantity, 0);
                const stockQty = item.quantity - soldQty;
                return (
                  <tr key={item.id} className="hover:bg-blue-50/30 transition-colors">
                    <td className="px-6 py-4 font-medium text-gray-900">{item.brand}</td>
                    <td className="px-6 py-4 text-gray-600">{item.productLine || 'N/A'}</td>
                    <td className="px-6 py-4 text-gray-600">{item.capacity}</td>
                    <td className="px-6 py-4 font-mono text-xs text-blue-600">{item.sn || 'N/A'}</td>
                    <td className="px-6 py-4 text-center font-bold">
                      <span className={stockQty <= 0 ? 'text-red-500' : 'text-gray-900'}>{stockQty}</span>
                    </td>
                    <td className="px-6 py-4 text-gray-900">{item.importPriceTWD.toLocaleString()}</td>
                    <td className="px-6 py-4 text-blue-600 font-bold">{(item.importPriceTWD * stockQty).toLocaleString()}</td>
                    <td className="px-6 py-4 text-emerald-600 font-bold">{(item.importPriceTWD * stockQty * financialParams.exchangeRate).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        item.status === 'Đạt' ? 'bg-green-100 text-green-700' :
                        item.status === 'Lỗi' ? 'bg-red-100 text-red-700' :
                        item.status === 'Đang kiểm định' ? 'bg-orange-100 text-orange-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {inventory.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-gray-400 italic">
                    Không có hàng tồn kho.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderCalculator = () => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1 space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <Calculator size={20} className="text-blue-600" />
              Tham số Tài chính
            </h3>
            <button 
              onClick={fetchLatestRate}
              disabled={isFetchingRate}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors disabled:opacity-50"
              title="Cập nhật tỷ giá từ Google"
            >
              {isFetchingRate ? <Loader2 size={18} className="animate-spin" /> : <RefreshCw size={18} />}
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Tỷ giá TWD/VND</label>
              <div className="relative">
                <input 
                  type="number"
                  className="w-full p-2 pl-8 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  value={financialParams.exchangeRate}
                  onChange={e => setFinancialParams({...financialParams, exchangeRate: Number(e.target.value)})}
                />
                <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Phí vận chuyển (VND/ổ)</label>
              <div className="relative">
                <input 
                  type="number"
                  className="w-full p-2 pl-8 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  value={financialParams.shippingFee}
                  onChange={e => setFinancialParams({...financialParams, shippingFee: Number(e.target.value)})}
                />
                <Truck className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Thuế nhập khẩu (%)</label>
              <input 
                type="number"
                className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={financialParams.importTax}
                onChange={e => setFinancialParams({...financialParams, importTax: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Phí kiểm định (VND/ổ)</label>
              <input 
                type="number"
                className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={financialParams.testingFee}
                onChange={e => setFinancialParams({...financialParams, testingFee: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Phí bảo hành dự phòng (VND/ổ)</label>
              <div className="relative">
                <input 
                  type="number"
                  className="w-full p-2 pl-8 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  value={financialParams.warrantyFee}
                  onChange={e => setFinancialParams({...financialParams, warrantyFee: Number(e.target.value)})}
                />
                <ShieldCheck className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Lợi nhuận mục tiêu (%)</label>
              <input 
                type="number"
                className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={financialParams.targetProfit}
                onChange={e => setFinancialParams({...financialParams, targetProfit: Number(e.target.value)})}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4">Kết quả Tính toán Lô hàng</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 text-gray-500 uppercase text-xs font-bold">
                <tr>
                  <th className="px-4 py-3">Sản phẩm</th>
                  <th className="px-4 py-3">Giá nhập (TWD)</th>
                  <th className="px-4 py-3">Giá vốn (VND)</th>
                  <th className="px-4 py-3">Chi phí (VND)</th>
                  <th className="px-4 py-3 text-blue-600">Giá bán (VND)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {inventory.map(item => {
                  const calc = calculateFinalPrice(item.importPriceTWD);
                  return (
                    <tr key={item.id}>
                      <td className="px-4 py-3">{item.brand} {item.capacity}</td>
                      <td className="px-4 py-3 font-bold">{item.importPriceTWD.toLocaleString()}</td>
                      <td className="px-4 py-3">{Math.round(calc.baseCostVND).toLocaleString()}</td>
                      <td className="px-4 py-3">{Math.round(calc.totalExpenses).toLocaleString()}</td>
                      <td className="px-4 py-3 font-bold text-blue-600">{Math.round(calc.finalPrice).toLocaleString()}</td>
                    </tr>
                  );
                })}
                {inventory.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-gray-400">
                      Hãy thêm linh kiện vào kho để tính toán.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSales = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <ShoppingCart size={20} className="text-green-600" />
            Ghi nhận Bán hàng
          </h3>
          <button 
            onClick={() => {
              // Just a UI feedback to show it "refreshed"
              const btn = document.getElementById('refresh-sales-btn');
              if (btn) {
                btn.classList.add('animate-spin');
                setTimeout(() => btn.classList.remove('animate-spin'), 500);
              }
            }}
            className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-green-600 transition-colors"
          >
            <RefreshCw id="refresh-sales-btn" size={16} />
            Làm mới thương hiệu
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <select 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
            value={newSale.itemId}
            onChange={e => setNewSale({...newSale, itemId: e.target.value})}
          >
            <option value="">Chọn linh kiện (Thương hiệu)...</option>
            {inventory.filter(item => item.status !== 'Lỗi').map(item => {
              const soldQty = sales.filter(s => s.itemId === item.id).reduce((sum, s) => sum + s.quantity, 0);
              const stockQty = item.quantity - soldQty;
              return (
                <option key={item.id} value={item.id} disabled={stockQty <= 0}>
                  {item.brand} {item.capacity ? `(${item.capacity})` : ''} - Tồn: {stockQty} {item.status !== 'Đạt' ? `[${item.status}]` : ''}
                </option>
              );
            })}
          </select>
          <input 
            placeholder="Tên khách hàng" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
            value={newSale.customerName}
            onChange={e => setNewSale({...newSale, customerName: e.target.value})}
          />
          <input 
            type="number"
            placeholder="Số lượng" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
            value={newSale.quantity || ''}
            onChange={e => setNewSale({...newSale, quantity: Number(e.target.value)})}
          />
          <input 
            type="number"
            placeholder="Giá bán (VND)" 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
            value={newSale.salePriceVND || ''}
            onChange={e => setNewSale({...newSale, salePriceVND: Number(e.target.value)})}
          />
          <select 
            className="p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
            value={newSale.paymentStatus}
            onChange={e => setNewSale({...newSale, paymentStatus: e.target.value as any})}
          >
            <option>Chưa thanh toán</option>
            <option>Đã thanh toán</option>
            <option>Cọc</option>
          </select>
          <button 
            onClick={handleAddSale}
            className="bg-green-600 text-white py-2 rounded-lg font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
          >
            <Plus size={18} /> Bán
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50/50">
          <h3 className="font-bold text-gray-800">Lịch sử Bán hàng</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 text-gray-500 uppercase text-xs font-bold">
              <tr>
                <th className="px-6 py-4">Linh kiện</th>
                <th className="px-6 py-4">Khách hàng</th>
                <th className="px-6 py-4 text-center">Số lượng</th>
                <th className="px-6 py-4">Giá bán (VND)</th>
                <th className="px-6 py-4">Tổng tiền (VND)</th>
                <th className="px-6 py-4">Ngày bán</th>
                <th className="px-6 py-4">Trạng thái</th>
                <th className="px-6 py-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {sales.map((sale) => {
                const item = inventory.find(i => i.id === sale.itemId);
                return (
                  <tr key={sale.id} className="hover:bg-green-50/30 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-medium">{item?.brand} {item?.capacity}</p>
                      <p className="text-xs text-gray-400 font-mono">{item?.sn}</p>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{sale.customerName}</td>
                    <td className="px-6 py-4 text-center font-bold">{sale.quantity}</td>
                    <td className="px-6 py-4 text-gray-900">{sale.salePriceVND.toLocaleString()}</td>
                    <td className="px-6 py-4 font-bold text-green-600">{(sale.salePriceVND * sale.quantity).toLocaleString()}</td>
                    <td className="px-6 py-4 text-gray-500">{sale.saleDate}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        sale.paymentStatus === 'Đã thanh toán' ? 'bg-green-100 text-green-700' :
                        sale.paymentStatus === 'Cọc' ? 'bg-blue-100 text-blue-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {sale.paymentStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => deleteSale(sale.id)}
                        className="text-red-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {sales.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-400 italic">
                    Chưa có giao dịch bán hàng nào.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderFinance = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Wallet size={20} className="text-emerald-600" />
            Ghi nhận Thu / Chi
          </h3>
          <div className="space-y-4">
            <div className="flex gap-2">
              <button 
                onClick={() => setNewFinance({...newFinance, type: 'Thu'})}
                className={`flex-1 py-2 rounded-lg font-bold transition-all ${newFinance.type === 'Thu' ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-500'}`}
              >
                Thu
              </button>
              <button 
                onClick={() => setNewFinance({...newFinance, type: 'Chi'})}
                className={`flex-1 py-2 rounded-lg font-bold transition-all ${newFinance.type === 'Chi' ? 'bg-rose-600 text-white' : 'bg-gray-100 text-gray-500'}`}
              >
                Chi
              </button>
            </div>
            <input 
              placeholder="Hạng mục (VD: Tiền điện, Tiền hàng...)" 
              className="w-full p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={newFinance.category}
              onChange={e => setNewFinance({...newFinance, category: e.target.value})}
            />
            <input 
              type="number"
              placeholder="Số tiền (VND)" 
              className="w-full p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={newFinance.amount || ''}
              onChange={e => setNewFinance({...newFinance, amount: Number(e.target.value)})}
            />
            <input 
              type="date"
              className="w-full p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={newFinance.date}
              onChange={e => setNewFinance({...newFinance, date: e.target.value})}
            />
            <textarea 
              placeholder="Ghi chú..." 
              className="w-full p-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none h-20"
              value={newFinance.note}
              onChange={e => setNewFinance({...newFinance, note: e.target.value})}
            />
            <button 
              onClick={handleAddFinance}
              className={`w-full py-2 rounded-lg font-bold text-white transition-colors ${newFinance.type === 'Thu' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'}`}
            >
              Thêm Ghi chép
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Receipt size={20} className="text-blue-600" />
            Báo cáo Tài chính Nhanh
          </h3>
          <div className="space-y-6">
            <div className="p-4 bg-gray-50 rounded-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-500">Tổng Thu:</span>
                <span className="font-bold text-emerald-600">{stats.totalIncome.toLocaleString()} VND</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500">Tổng Chi:</span>
                <span className="font-bold text-rose-600">{stats.totalExpense.toLocaleString()} VND</span>
              </div>
              <div className="pt-3 border-t border-gray-200 flex justify-between items-center">
                <span className="font-bold">Lợi nhuận ròng:</span>
                <span className={`font-bold text-lg ${(stats.totalIncome - stats.totalExpense) >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {(stats.totalIncome - stats.totalExpense).toLocaleString()} VND
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-xs font-bold text-gray-400 uppercase">Ghi chú gần đây</p>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                {finance.slice().reverse().map(f => (
                  <div key={f.id} className="p-3 bg-white border border-gray-100 rounded-lg flex justify-between items-center">
                    <div>
                      <p className="text-sm font-bold">{f.category}</p>
                      <p className="text-xs text-gray-400">{f.date}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${f.type === 'Thu' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {f.type === 'Thu' ? '+' : '-'}{f.amount.toLocaleString()}
                      </p>
                      <button onClick={() => deleteFinance(f.id)} className="text-gray-300 hover:text-red-500">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
                {finance.length === 0 && <p className="text-sm text-gray-400 italic">Chưa có ghi chép nào.</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTrade = () => {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Languages size={20} className="text-purple-600" />
            Soạn thảo & Dịch thuật Giao thương
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Nhập nội dung cần dịch (Bất kỳ ngôn ngữ nào)</label>
              <textarea 
                className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none h-32 text-sm"
                placeholder="Ví dụ: Tôi muốn hỏi giá 100 ổ cứng WD 1TB cũ, tình trạng sức khỏe tốt..."
                value={tradeText}
                onChange={(e) => setTradeText(e.target.value)}
              />
            </div>
            <button 
              onClick={handleTranslate}
              disabled={isTranslating || !tradeText.trim()}
              className="w-full py-3 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isTranslating ? <Loader2 size={20} className="animate-spin" /> : <Globe size={20} />}
              {isTranslating ? 'Đang dịch thuật...' : 'Dịch thuật Đa ngôn ngữ'}
            </button>
          </div>
        </div>

        {(translations.zh || translations.en || translations.vi) && (
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-gray-800">Kết quả Dịch thuật</h3>
              <div className="flex bg-gray-100 p-1 rounded-lg">
                {[
                  { id: 'zh', label: '中文' },
                  { id: 'en', label: 'EN' },
                  { id: 'vi', label: 'VN' }
                ].map(lang => (
                  <button
                    key={lang.id}
                    onClick={() => setTradeLang(lang.id as any)}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${tradeLang === lang.id ? 'bg-white text-purple-600 shadow-sm' : 'text-gray-500'}`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6 border border-purple-100 rounded-xl bg-purple-50/30">
              <h4 className="font-bold text-purple-800 mb-2 flex items-center gap-2">
                <Globe size={16} /> {tradeLang === 'zh' ? 'Tiếng Trung (Phồn thể)' : tradeLang === 'en' ? 'English' : 'Tiếng Việt'}
              </h4>
              
              {tradeLang === 'zh' && translations.pinyin && (
                <div className="mb-3 p-2 bg-white/50 rounded border border-purple-50">
                  <p className="text-[10px] font-bold text-purple-400 uppercase mb-1">Pinyin</p>
                  <p className="text-xs text-purple-700 italic font-mono leading-relaxed">
                    {translations.pinyin}
                  </p>
                </div>
              )}

              <pre className="bg-white p-4 rounded-lg text-sm border border-purple-100 whitespace-pre-wrap font-sans min-h-[150px] text-gray-800 leading-relaxed">
                {translations[tradeLang] || 'Chưa có bản dịch.'}
              </pre>
              
              <button 
                onClick={() => navigator.clipboard.writeText(translations[tradeLang] || '')}
                className="mt-4 w-full py-2 bg-purple-600 text-white rounded-lg text-sm font-bold hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
              >
                Sao chép bản dịch
              </button>
            </div>
          </div>
        )}

        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <TrendingUp size={20} className="text-green-600" />
            Phân tích Thị trường & Tỷ giá
          </h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-4 bg-green-50 rounded-xl border border-green-100">
              <RefreshCw className="text-green-600 mt-1 shrink-0" size={18} />
              <div>
                <p className="font-bold text-green-800">Cập nhật Tỷ giá</p>
                <p className="text-sm text-green-700">
                  Tỷ giá TWD/VND hiện tại đang ở mức ổn định ({financialParams.exchangeRate}). 
                  Tuy nhiên, cần theo dõi sát sao chỉ số XAUUSD (Vàng). 
                  Nếu giá vàng thế giới tăng, áp lực lên các đồng tiền châu Á có thể khiến TWD giảm giá nhẹ so với VND.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <FileText className="text-blue-600 mt-1 shrink-0" size={18} />
              <div>
                <p className="font-bold text-blue-800">Lời khuyên Giao dịch</p>
                <p className="text-sm text-blue-700">
                  Nên chia nhỏ các đợt thanh toán nếu lô hàng lớn để trung bình giá tỷ giá. 
                  Luôn yêu cầu đối tác cung cấp Serial Number trước khi thanh toán 100%.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      {/* Sidebar / Navigation */}
      <div className="fixed left-0 top-0 h-full w-20 md:w-64 bg-white border-r border-gray-100 flex flex-col z-50">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <LayoutDashboard size={24} />
          </div>
          <span className="hidden md:block font-bold text-xl tracking-tight">SmartBiz <span className="text-blue-600">TW-VN</span></span>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {[
            { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
            { id: 'finance', label: 'Thu chi', icon: Wallet },
            { id: 'sales', label: 'Bán hàng', icon: ShoppingCart },
            { id: 'inventory', label: 'Nhập kho', icon: Package },
            { id: 'stock', label: 'Tồn kho', icon: Package },
            { id: 'calculator', label: 'Tính Tài chính', icon: Calculator },
            { id: 'trade', label: 'Giao thương', icon: Languages },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-100' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              <item.icon size={20} />
              <span className="hidden md:block font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-gray-100">
          <div className="hidden md:block p-4 bg-gray-50 rounded-xl">
            <p className="text-xs font-bold text-gray-400 uppercase mb-2">Người dùng</p>
            <p className="text-sm font-bold truncate">qingsonggemini115@gmail.com</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="pl-20 md:pl-64 pt-6 pr-6 pb-20">
        <div className="max-w-7xl mx-auto">
          <header className="mb-8 flex justify-between items-end">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {activeTab === 'dashboard' && 'Bảng Điều khiển'}
                {activeTab === 'inventory' && 'Nhập kho Linh kiện'}
                {activeTab === 'stock' && 'Thống kê Tồn kho'}
                {activeTab === 'calculator' && 'Công cụ Tính toán Tài chính'}
                {activeTab === 'sales' && 'Quản lý Bán hàng'}
                {activeTab === 'finance' && 'Quản lý Thu chi'}
                {activeTab === 'trade' && 'Hỗ trợ Giao thương Quốc tế'}
              </h1>
              <p className="text-gray-500 mt-1">
                Chào mừng trở lại, hệ thống đã sẵn sàng xử lý dữ liệu.
              </p>
            </div>
            <div className="hidden sm:flex items-center gap-4 bg-white p-2 rounded-xl border border-gray-100 shadow-sm">
              <div className="text-right">
                <p className="text-xs font-bold text-gray-400 uppercase">Tỷ giá TWD</p>
                <p className="text-sm font-bold text-blue-600">{financialParams.exchangeRate} VND</p>
              </div>
              <div className="h-8 w-px bg-gray-100"></div>
              <div className="text-right">
                <p className="text-xs font-bold text-gray-400 uppercase">Lợi nhuận</p>
                <p className="text-sm font-bold text-green-600">{financialParams.targetProfit}%</p>
              </div>
            </div>
          </header>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && renderDashboard()}
              {activeTab === 'inventory' && renderInventory()}
              {activeTab === 'stock' && renderStock()}
              {activeTab === 'calculator' && renderCalculator()}
              {activeTab === 'sales' && renderSales()}
              {activeTab === 'finance' && renderFinance()}
              {activeTab === 'trade' && renderTrade()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
